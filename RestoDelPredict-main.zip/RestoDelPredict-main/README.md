## Restaurant Product Delivery Time Prediction

### created a environment

```
conda create -p restoenv python==3.8

conda activate restoenv/
```

### Install all necessary libraries

```
pip install -r requirements.txt
```
