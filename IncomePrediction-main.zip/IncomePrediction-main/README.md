## End to End ML Project

### Created an environment
```
conda create -p venv python==3.8
```

### Install all necessary libraries
```
pip install -r requirements.txt
```